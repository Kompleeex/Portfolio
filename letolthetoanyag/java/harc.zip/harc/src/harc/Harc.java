package harc;

import java.util.Random;

public class Harc {

    public static void main(String[] args) {
        
        Random rnd = new Random();
     
        int harcos = 10;
        int Varázsló = 10;
        
        System.out.println("életek: \n" + "Harcos élete: " + harcos + "\n" + "Varázsló élete: " + Varázsló );
        
        while ( harcos > 0 && Varázsló > 0){
            
            int Harcospozi = rnd.nextInt(3);
            int varazslopozi = rnd.nextInt(3);
            int heal = rnd.nextInt(2)+1;

            if (Harcospozi == varazslopozi){
                harcos -= rnd.nextInt(6)+1;
                Varázsló -= rnd.nextInt(6)+1;
            
                System.out.println("Csata tőrtént: ");
                System.out.println("Harcos élete a csata után: " + harcos);
                System.out.println("varázsló élete a csata után:" + Varázsló);
                if(harcos > 0 && Varázsló > 0){
                    if(heal == 1){
                        System.out.println("Felészülés az újabb lehetséges csatára: ");               
                        harcos += rnd.nextInt(4)+1;
                        System.out.println("A harcos Élet ereje megnövekedett " + harcos + "-életerőre");
                    }    
                    else if( heal == 2){
                        System.out.println("Felészülés az újabb lehetséges csatára: ");
                        Varázsló += rnd.nextInt(4)+1;
                        System.out.println("A Varázsló Élet ereje megnövekedett " + Varázsló + "-életerőre");
                    }
                    else {
                        System.out.println("nem történt regenerálódás");
                    }
                }
            }
            else{
                System.out.println("Nincs csata");
            }
        }    
        System.out.println(" A játék véget ért");
    }
}    
               
        
            
            
            
                 
                
            
            

        
        
        
    


